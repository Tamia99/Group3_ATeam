module.exports = {
    assetsDir: 'static',
    devServer: {
        proxy: 'http://localhost:5000/'
    }
}