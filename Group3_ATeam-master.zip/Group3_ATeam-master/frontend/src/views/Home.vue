
<template>
  <div class="home">
    <!--<img alt="Vue logo" src="../assets/logo.png">-->
    <!--<HelloWorld msg="Welcome to Your Vue.js App"/>-->
    <p>Ramdom number from backend: {{ randomNumber }}</p>
    <button @click="getRandom"> New random number</button>
  </div>
</template>

<script>
// @ is an alias to /src
import HelloWorld from '../components/HelloWorld.vue'
import axios from 'axios'
export default {
  name: 'Home',
  components: {
    HelloWorld
  },
  data (){
    return {
      randomNumber: 0
    }
  },
  methods:{
    getRandom (){
      this.randomNumber = this.getRandomFromBackend()
    },
    getRandomFromBackend (){
      const path = 'http://localhost:5000/api/random'
      axios.get(path)
      .then(response => {
        this.randomNumber = response.data.randomNumber
      })
      .catch(error => {
        console.log(error)
      })
    }
  },
}
</script>
