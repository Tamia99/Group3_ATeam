<template>
    <h1>This is the houseList page</h1>
    
</template>