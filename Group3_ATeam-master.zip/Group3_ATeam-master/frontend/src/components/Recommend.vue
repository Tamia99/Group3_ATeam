<template>
    <h1>Here to see recommendations for you</h1>
</template>